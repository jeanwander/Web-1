async function buscarSerie(){

const nomeSerie =
document.getElementById("pesquisa").value;

const resultado =
document.getElementById("resultado");

resultado.innerHTML="";

if(nomeSerie===""){
    resultado.innerHTML=
    "<h3>Digite uma série</h3>";

    return;
}

try{
const resposta =
await fetch(
`https://api.tvmaze.com/search/shows?q=${nomeSerie}`
);

const dados =
await resposta.json();


if(dados.length===0){
resultado.innerHTML=
"<h3>Nenhuma série encontrada</h3>";
return;
}


dados.forEach(item=>{

const serie = item.show;


let coluna =
document.createElement("div");

coluna.className =
"col-md-4";


let card =
document.createElement("div");

card.className =
"card card-serie shadow";


if(serie.image){

let imagem =
document.createElement("img");

imagem.src =
serie.image.medium;

imagem.className =
"card-img-top";

card.appendChild(imagem);

}
else{

let semImagem =
document.createElement("div");

semImagem.className =
"sem-imagem";

semImagem.innerText =
"Imagem não disponível";

card.appendChild(semImagem);
}

let corpo =
document.createElement("div");

corpo.className =
"card-body";

let titulo =
document.createElement("h5");

titulo.className =
"card-title";

titulo.innerText =
serie.name;


let score =
document.createElement("p");

score.className="score";

score.innerHTML=
`⭐ Score: ${item.score}`;


corpo.appendChild(titulo);

corpo.appendChild(score);


card.appendChild(corpo);

coluna.appendChild(card);

resultado.appendChild(coluna);
});
}

catch(erro){
resultado.innerHTML=
"<h3>Erro ao carregar dados</h3>";
console.log(erro);
}
}