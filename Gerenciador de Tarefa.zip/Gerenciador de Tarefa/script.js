function adicionarTarefa(){

let texto =
document.getElementById("tarefa").value;

let prioridade =
document.getElementById("prioridade").value;

if(texto==""){
    alert("Digite uma tarefa!");
    return;
}

let lista =
document.getElementById("listaTarefas");

lista.innerHTML += `

<div class="col-md-4 mb-3">

<div class="card card-tarefa ${prioridade}">

<div class="card-body">

<h5 class="card-title">
${texto}
</h5>

<p>
Prioridade:
<b>${prioridade}</b>
</p>

<select
class="form-select"
onchange="alterarPrioridade(this)">

<option value="alta">
Alta
</option>

<option value="media">
Média
</option>

<option value="baixa">
Baixa
</option>

</select>

</div>

</div>

</div>

`;

document.getElementById("tarefa").value="";

}

function alterarPrioridade(select){

let card =
select.closest(".card");

card.classList.remove(
"alta",
"media",
"baixa"
);

card.classList.add(
select.value
);

}